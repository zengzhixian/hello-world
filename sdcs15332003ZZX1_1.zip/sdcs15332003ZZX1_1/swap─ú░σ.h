template<class T>
void  swap(T arr[],int a,int b) {
	T c;
	c=arr[a];
	arr[a]=arr[b];
	arr[b]=c;
}
